function dynamicDTFields(post_type, fields) {
	console.log(`${post_type}`);
		
	let dynamic_fields = [];
	
	// Iterate over dt fields, converting to dynamic mapped make fields.
	for (const [key, field] of Object.entries(fields)) {
  		console.log(`${key}: ${field}`);
		
		let proceed_with_conversion = true;
		
		// Ensure certain fields, types & states are ignored.
		if(["last_modified", "post_date"].includes(key) || [].includes(field.type) || field.private || field.hidden) {
			proceed_with_conversion = false;
		}
		
		if(proceed_with_conversion) {
		
			// Proceed with field conversion.
			let field_obj = {};
			field_obj.name = key;
			field_obj.label = field.name;
			field_obj.required = (field.required) ? field.required : false;
			field_obj.help = (field.description) ? field.description : "";

			let field_converted = true;
			switch(field.type) {
				case "text":
				case "textarea":
					field_obj.type = "text";

					if(["textarea"].includes(field.type)) {
						field_obj.multiline = true;
					}
					break;
				case "communication_channel":
					field_obj.type = "collection";
					field_obj.spec = [{
						"name": "value",
						"type": "text"
					}];
					break;
				case "date":
					field_obj.type = "date";
					break;
				case "boolean":
					field_obj.type = "boolean";
					break;
				case "key_select":
				case "multi_select":
					field_obj.type = "select";

					if(["multi_select"].includes(field.type)) {
						field_obj.multiple = true;
					}

					if(field.default) {
						let default_options = [];
						for (const [default_key, default_option] of Object.entries(field.default)) {
							console.log(`${default_key}: ${default_option}`);

							let default_obj = {};
							default_obj.value = default_key;
							default_obj.label = default_option.label;

							default_options.push(default_obj);
						}
						field_obj.options = default_options;
					}
					break;
				case "number":
					field_obj.type = "number";
					break;
				case "tags":
				case "array":
					field_obj.type = "array";
					break;
				case "link":
					field_obj.type = "url";
					break;
				case "connection":
				case "user_select":
				case "task":
				case "location":
				case "location_meta":
					// Types Currently Not Supported!
					// TODO: Nested parameter feature might be an option for future support!
					field_converted = false;
					break;
				default:
					field_converted = false;
					break;
			}

			// Only display if it has successfully gone through the conversion process!
			if(field_converted) {
				dynamic_fields.push(field_obj);
			}
		}
	}
	
	// Return converted fields.
	return dynamic_fields;
}