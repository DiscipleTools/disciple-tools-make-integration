function packageDTFields(fields, field_settings) {
	let packaged_dt_fields = {};

	// Iterate over submitted fields.
	for (const [key, field] of Object.entries(fields)) {
	
		// Find corresponding field setting.
		field_settings.forEach(function (field_setting) {
			if(key.toLowerCase() == field_setting.name.toLowerCase()) {
			
				// Package accordingly, based on corresponding field type.
				switch(field_setting.type) {
					case "number":
					case "text":
					case "boolean":
						packaged_dt_fields[key] = field;
						break;
					case "date":
						packaged_dt_fields[key] = iml.parseDate(field, "X");
						break;
					case "select":
						if(field_setting.multiple) {
							let options = [];
							field.forEach(function (field_option){
								options.push({
									"value": field_option
								});
							});
							
							packaged_dt_fields[key] = {
								"values": options
							};
						}else{
							packaged_dt_fields[key] = field;
						}
						break;
					case "array":

						// Ensure notes/comments are packaged differently!
						if(["notes"].includes(key.toLowerCase())) {

							let notes = [];
							field.forEach(function (field_option){
								notes.push(field_option);
							});

							if(notes.length > 0) {
								packaged_dt_fields[key] = notes;
							}

						}else{

							// Proceed with default packaging of array objects.
							let options = [];
							field.forEach(function (field_option){
								options.push({
									"value": field_option
								});
							});

							if(options.length > 0) {
								packaged_dt_fields[key] = {
									"values": options
								};
							}
						}
						break;
					case "collection":
						if(field && field.value && field.value !== "") {
							packaged_dt_fields[key] = [{
								"value": field.value
							}];
						}
						break;
				}
			}
		});
	}
	
	// Finally, return packaged dt fields.
	return packaged_dt_fields;
}